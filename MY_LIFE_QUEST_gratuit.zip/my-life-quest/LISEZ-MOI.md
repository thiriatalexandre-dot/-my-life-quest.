# MY LIFE QUEST — version gratuite

Cette version est un projet web autonome. Elle n'utilise pas Lovable, aucun abonnement, aucune API payante et aucun générateur IA.

## Ce qui est inclus
- 49 objectifs de vie en grille 7×7.
- 500 expériences pré-écrites (pas générées automatiquement).
- 10 projets légendaires.
- 50 emplacements de défis transmis par les proches, vides au départ.
- Interface responsive et thème sombre élégant.
- Recherche, filtres, notes et validation des objectifs.
- Authentification et sauvegarde privée via Supabase (offre gratuite, sous réserve des quotas et conditions du fournisseur).

## Important : activation gratuite nécessaire
Le dossier contient le site, mais il n'est pas encore publié sur Internet. Pour avoir des comptes privés, il faut créer tes propres comptes gratuits chez un hébergeur et un service de base de données. Il n'y a pas de solution honnête permettant de publier un site public avec comptes privés sans aucun hébergement ni configuration.

### 1. Créer la base de données privée
1. Avec l'aide d'un parent si nécessaire, crée un projet sur https://supabase.com/ (offre Free).
2. Ouvre le SQL Editor et exécute le contenu de `schema.sql`.
3. Dans Project Settings > API, copie l'URL du projet et la clé publique `anon` / `publishable` (jamais la clé `service_role` ou une clé secrète).
4. Dans `app.js`, remplace les deux chaînes vides au début par l'URL et la clé publique.

Les règles RLS dans `schema.sql` imposent que chaque compte ne puisse lire ou modifier que ses propres lignes. Ne désactive jamais ces règles.

### 2. Publier gratuitement
Option simple : GitHub Pages (offre gratuite pour un dépôt public).
1. Crée un dépôt GitHub public et ajoute `index.html`, `style.css`, `app.js`, `data.json`.
2. Dans Settings > Pages, active le déploiement depuis la branche principale.
3. Le site sera accessible via une adresse `github.io`.

Attention : tout ce qui est dans le dépôt public est public. N'y mets jamais de notes, photos ou données personnelles. Les données des utilisateurs sont dans Supabase, protégées par RLS. Le fichier `schema.sql` ne contient aucun secret. Les clés publiques Supabase peuvent être présentes côté navigateur si les règles RLS sont correctes.

## Limites à connaître
- Les photos/souvenirs en fichiers ne sont pas activés : le stockage peut avoir des quotas et demande une configuration supplémentaire. Les notes texte sont disponibles.
- Les données personnalisées sont sauvegardées dans Supabase une fois les étapes de configuration terminées.
- Les quotas gratuits de Supabase et GitHub peuvent évoluer et ne garantissent pas une disponibilité illimitée.
- L'application actuelle propose la validation et les notes ; les outils d'édition sont simples et peuvent être enrichis ensuite.
- Ne mets jamais d'adresse personnelle, d'école, de données sensibles ou de photos identifiantes dans une version publique sans réflexion et accord approprié.

## Structure
- `index.html` : page d'accueil et interface
- `style.css` : design responsive
- `app.js` : logique de l'application
- `data.json` : contenu initial des 4 espaces
- `schema.sql` : table et règles de confidentialité Supabase
